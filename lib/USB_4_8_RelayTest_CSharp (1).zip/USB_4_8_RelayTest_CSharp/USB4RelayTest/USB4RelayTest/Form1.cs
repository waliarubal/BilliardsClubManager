﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FTD2XX_NET;


namespace WindowsFormsApplication1
{
    
    public partial class Form1 : Form
    {
        public FTDI myFtdiDevice = new FTDI();
        FTDI.FT_STATUS ftStatus;
        byte[] sentBytes = new byte[2];
        uint receivedBytes;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            ftStatus = myFtdiDevice.OpenByIndex(0);
            if (ftStatus != FTDI.FT_STATUS.FT_OK)
            {
                // Wait for a key press
                Console.WriteLine("Failed to open device (error " + ftStatus.ToString() + ")");
                Console.ReadKey();
                return;
            }

            ftStatus = myFtdiDevice.SetBaudRate(921600);
             if (ftStatus != FTDI.FT_STATUS.FT_OK)
            {
                // Wait for a key press
                Console.WriteLine("Failed to set baudrate (error " + ftStatus.ToString() + ")");
                Console.ReadKey();
                return;
            }

             ftStatus = myFtdiDevice.SetBitMode(255,4);
             if (ftStatus != FTDI.FT_STATUS.FT_OK)
            {
                // Wait for a key press
                Console.WriteLine("Failed to set bit mode (error " + ftStatus.ToString() + ")");
                Console.ReadKey();
                return;
            }

             sentBytes[0] = 0;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
               sentBytes[0]=(byte)(sentBytes[0] | 1);           
            else            
                sentBytes[0]=(byte)(sentBytes[0] & 254);             
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 2);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 253);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 4);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 251);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 8);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 247);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 16);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 239);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 32);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 223);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 64);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 191);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked)
                sentBytes[0] = (byte)(sentBytes[0] | 128);
            else
                sentBytes[0] = (byte)(sentBytes[0] & 127);
            myFtdiDevice.Write(sentBytes, 1, ref receivedBytes);
        }
    }
}
